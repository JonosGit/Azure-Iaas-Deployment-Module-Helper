<#
.SYNOPSIS
Written By John Lewis
email: jonos@live.com
IaaS Deployment Module for Azure

Version 1.2

.DESCRIPTION
Deploys 30 different Market Images on a new or existing VNET. Supports post deployment configuration through Azure Extensions.
Market Images supported: Redhat 6.7 and 7.2, PFSense 2.5, Windows 2008 R2, Windows 2012 R2, Ubuntu 14.04, CentOs 7.2, SUSE, SQL 2016 (on W2K12R2), R Server on Windows, Windows 2016 (Preview), Checkpoint Firewall, FreeBsd, Oracle Linux, Puppet, Splunk, Oracle Web-Logic, Oracle DB, Bitnami Lamp, Bitnami PostGresSql, Bitnami nodejs, Bitnami Elastics, Bitnami MySql, SharePoint 2013/2016, Barracuda NG, Barracuda SPAM, F5 BigIP, F5 App Firewall, SAP, Solar Winds, Bitnami JRuby, Bitnami Neos, Bitnami TomCat, Bitnami redis, Bitnami hadoop

Please update the two global parameters  (Regional Azure Location and Azure Profile File) prior to importing the module

#>

Param(
$Location = 'WestUs',
$Profile = "C:\Temp\outlook.json"
	)


Function Get-AzureVersion {
$name='Azure'
if(Get-Module -ListAvailable |
	Where-Object { $_.name -eq $name })
{
$ver = (Get-Module -ListAvailable | Where-Object{ $_.Name -eq $name }) |
	select version -ExpandProperty version
$currentver = $ver
	if($currentver-le '2.0.0'){
	Write-Host "expected version 2.0.1 found $ver" -ForegroundColor DarkRed
	exit
	}
}
else
{
	Write-Host �The Azure PowerShell module is not installed.�
	exit
}
}

Function validate-profile {

$fileexist = Test-Path $Profile
  if($fileexist)
  {
  Select-AzureRmProfile -Path $Profile | Out-Null
  }
  else
  {
  Write-Host "Please enter your credentials"
  Add-AzureRmAccount
  Save-AzureRmProfile -Path $Profile -Force
  Write-Host "Saved Profile to $Profile"
  }
}

function ChkDepends {

if(!$Image) {
Write-Host "Please Enter vmMarketImage"
exit }
	elseif(!$VMName) {
	Write-Host "Please Enter vmName"
	exit}
		elseif(!$VNetName) {
		Write-Host "Please Enter vNet Name"
		exit}
			elseif(!$rg) {
			Write-Host "Please Enter Resource Group Name"
			exit}
					elseif(!$ConfigIPs) {
					Write-Host "Please Enter IP Configuration"
					exit }
								elseif(!$vnetrg) {
								Write-Host "Please Enter VNET Resource Group Name"
								exit
										}
Get-AzureVersion
OrphanChk
New-AzResGrp -rg $rg
if($AddVnet -eq 'True'){New-AzVnet -VNETName $VNetName -vnetrg $vnetrg } 
if($NSGEnabled -eq 'True'){New-AzNSG -NSGName $NSGName -rg $vnetrg } 
}

function ChkDependsvnet {
if($AddVnet -eq 'True') {
Write-Host "AddVnet Found True, Verifying dependents."
}
	elseif(!$AddRange) {
	Write-Host "Please Enter Address Range"
	exit}
		elseif(!$VNetName) {
		Write-Host "Please Enter vNet Name"
		exit}
			elseif(!$SubnetAddPrefix1) {
			Write-Host "Must have at least 1 subnet"
			exit}
				elseif(!$SubnetNameAddPrefix1) {
				Write-Host "Must have at least 1 subnet"
				exit}
								elseif(!$vnetrg) {
								Write-Host "Please Enter VNET Resource Group Name"
								exit
											}
Get-AzureVersion
New-AzResGrp -rg $vnetrg
}


function ChkDependsnsg {
if($NSGEnabled -eq 'True') {
Write-Host "NSG Enabled Found True, Verifying dependents."
}
	elseif(!$NSGName) {
	Write-Host "Please Enter NSGName"
	exit } 
		elseif(!$Location) {
		Write-Host "Please Enter Location"
		exit }
								elseif(!$vnetrg) {
								Write-Host "Please Enter Resource Group Name"
								exit
											}
New-AzResGrp -rg $vnetrg
}

Function PubIPconfig {
	param(
	[string]$vnetrg = $vnetrg,
	[string]$Location = $Location,
	[string]$rg = $rg,
	[string]$InterfaceName1 = $InterfaceName1,
	[string]$DNLabel = $DNLabel
	)
if($AddFQDN -eq 'True')
{
$global:PIp = New-AzureRmPublicIpAddress -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -AllocationMethod "Dynamic" -DomainNameLabel $DNLabel �Confirm:$false -WarningAction SilentlyContinue
}
else
{
$global:PIp = New-AzureRmPublicIpAddress -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -AllocationMethod "Dynamic" �Confirm:$false -WarningAction SilentlyContinue
}
}

Function PubDNSconfig {
if($AddFQDN -eq 'True')
{
Write-Host "Creating FQDN: " $DNLabel.$Location.cloudapp.azure.com
}
else
{
Write-Host "No DNS Name Specified"
}
}

Function ConfigNet {

switch ($ConfigIPs)
	{
		"PvtDualStat" {
Write-Host "Dual IP Configuration - Static"
PubIPconfig
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PublicIpAddressId $PIp.Id -PrivateIpAddress $PvtIPNic1 �Confirm:$false -WarningAction SilentlyContinue
$global:Interface2 = New-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet2].Id -PrivateIpAddress $PvtIPNic2 �Confirm:$false -WarningAction SilentlyContinue
}
		"PvtSingleStat" {
Write-Host "Single IP Configuration - Static"
PubIPconfig
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PublicIpAddressId $PIp.Id -PrivateIpAddress $PvtIPNic1 �Confirm:$false -WarningAction SilentlyContinue
}
		"StatPvtNoPubDual" {
Write-Host "Dual IP Configuration- Static - No Public"
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PrivateIpAddress $PvtIPNic1 �Confirm:$false -WarningAction SilentlyContinue
$global:Interface2 = New-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet2].Id -PrivateIpAddress $PvtIPNic2 �Confirm:$false -WarningAction SilentlyContinue
}
		"StatPvtNoPubSingle" {
Write-Host "Single IP Configuration - Static - No Public"
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PrivateIpAddress $PvtIPNic1 �Confirm:$false -WarningAction SilentlyContinue
}
		"Single" {
Write-Host "Default Single IP Configuration"
PubIPconfig
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PublicIpAddressId $PIp.Id �Confirm:$false -WarningAction SilentlyContinue
}
		"Dual" {
Write-Host "Default Dual IP Configuration"
PubIPconfig
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id -PublicIpAddressId $PIp.Id �Confirm:$false -WarningAction SilentlyContinue
$global:Interface2 = New-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet2].Id �Confirm:$false -WarningAction SilentlyContinue
}
		"NoPubSingle" {
Write-Host "Single IP - No Public"
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id �Confirm:$false -WarningAction SilentlyContinue
}
		"NoPubDual" {
Write-Host "Dual IP - No Public"
$global:VNet = Get-AzureRMVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Set-AzureRmVirtualNetwork
$global:Interface1 = New-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet1].Id �Confirm:$false -WarningAction SilentlyContinue
$global:Interface2 = New-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -Location $Location -SubnetId $VNet.Subnets[$Subnet2].Id �Confirm:$false -WarningAction SilentlyContinue
}
		default{"Nothing matched entry criteria"}
}
}

Function AddNICs {
Write-Host "Adding 2 Network Interface(s) $InterfaceName1 $InterfaceName2" -ForegroundColor White
$global:VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $global:Interface1.Id -Primary -WarningAction SilentlyContinue
$global:VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $global:Interface2.Id -WarningAction SilentlyContinue
}

Function AddNIC {
Write-Host "Adding Network Interface $InterfaceName1" -ForegroundColor White
$global:VirtualMachine = Add-AzureRmVMNetworkInterface -VM $VirtualMachine -Id $global:Interface1.Id -Primary -WarningAction SilentlyContinue
}

Function ConfigSet {
switch  ($ConfigIPs)
	{
		"PvtDualStat" {
AddNICs
}
		"PvtSingleStat" {
AddNIC
}
		"StatPvtNoPubDual" {
AddNICs
}
		"StatPvtNoPubSingle" {
AddNIC
}
		"Single" {
AddNIC
}
		"Dual" {
AddNICs
}
		"NoPubSingle" {
AddNIC
}
		"NoPubDual" {
AddNICs
}
		default{"An unsupported network configuration was referenced"
		break
					}
}
}
Function NSGEnabled
{
if($NSGEnabled -eq 'True'){
$nic1 = Get-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -ErrorAction SilentlyContinue
$nic2 = Get-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -ErrorAction SilentlyContinue
if($nic1)
{
$nsg = Get-AzureRmNetworkSecurityGroup -ResourceGroupName $vnetrg -Name $NSGName
$nic = Get-AzureRmNetworkInterface -ResourceGroupName $rg -Name $InterfaceName1
$nic.NetworkSecurityGroup = $nsg
Set-AzureRmNetworkInterface -NetworkInterface $nic | Out-Null
$secrules = Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg | Get-AzureRmNetworkSecurityRuleConfig | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationPortRange,SourceAddressPrefix,Access | Format-Table | Out-Null
$defsecrules = Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg | Get-AzureRmNetworkSecurityRuleConfig -DefaultRules | Format-Table | Out-Null
Write-Host "POST IMAGING TASK COMPLETED" -ForegroundColor White
Write-Host "Completed adding NSG to Network Interface $InterfaceName1" -ForegroundColor White
}
if($nic2)
{
$nsg = Get-AzureRmNetworkSecurityGroup -ResourceGroupName $vnetrg -Name $NSGName
$nic = Get-AzureRmNetworkInterface -ResourceGroupName $rg -Name $InterfaceName2
$nic.NetworkSecurityGroup = $nsg
Set-AzureRmNetworkInterface -NetworkInterface $nic | Out-Null
$secrules = Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg | Get-AzureRmNetworkSecurityRuleConfig | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationPortRange,SourceAddressPrefix,Access | Format-Table | Out-Null
$defsecrules = Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg | Get-AzureRmNetworkSecurityRuleConfig -DefaultRules | Format-Table | Out-Null
Write-Host "Completed adding NSG to Network Interface $InterfaceName2" -ForegroundColor White
}
}
}
Function CreateVPN {
	param(
		$LocalNetPip = "207.21.2.1",
		$LocalAddPrefix = "10.10.0.0/24"


	)
Write-Host "VPN Creation can take up to 45 minutes!"
New-AzureRmLocalNetworkGateway -Name LocalSite -ResourceGroupName $vnetrg -Location $Location -GatewayIpAddress $LocalNetPip -AddressPrefix $LocalAddPrefix -ErrorAction Stop -WarningAction SilentlyContinue | Out-Null
Write-Host "Completed Local Network GW Creation"
$vpnpip= New-AzureRmPublicIpAddress -Name vpnpip -ResourceGroupName $vnetrg -Location $Location -AllocationMethod Dynamic -ErrorAction Stop -WarningAction SilentlyContinue
$vnet = Get-AzureRmVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg -ErrorAction Stop -WarningAction SilentlyContinue
$subnet = Get-AzureRmVirtualNetworkSubnetConfig -Name 'GatewaySubnet' -VirtualNetwork $vnet -WarningAction SilentlyContinue
$vpnipconfig = New-AzureRmVirtualNetworkGatewayIpConfig -Name vpnipconfig1 -SubnetId $subnet.Id -PublicIpAddressId $vpnpip.Id -WarningAction SilentlyContinue
New-AzureRmVirtualNetworkGateway -Name vnetvpn1 -ResourceGroupName $vnetrg -Location $Location -IpConfigurations $vpnipconfig -GatewayType Vpn -VpnType RouteBased -GatewaySku Standard -ErrorAction Stop -WarningAction SilentlyContinue | Out-Null
Write-Host "Completed VNET Network GW Creation"
Get-AzureRmPublicIpAddress -Name vpnpip -ResourceGroupName $rg -WarningAction SilentlyContinue
Write-Host "Configure Local Device with Azure VNET vpn Public IP"
}
Function ConnectVPN {
[PSObject]$gateway1 = Get-AzureRmVirtualNetworkGateway -Name vnetvpn1 -ResourceGroupName $vnetrg -WarningAction SilentlyContinue
[PSObject]$local = Get-AzureRmLocalNetworkGateway -Name LocalSite -ResourceGroupName $vnetrg -WarningAction SilentlyContinue
New-AzureRmVirtualNetworkGatewayConnection -ConnectionType IPSEC  -Name sitetosite -ResourceGroupName $vnetrg -Location $Location -VirtualNetworkGateway1 $gateway1 -LocalNetworkGateway2 $local -SharedKey '4321avfe' -Verbose -Force -RoutingWeight 10 -WarningAction SilentlyContinue| Out-Null
}
Function SelectNicDescrtipt {
if($ConfigIPs-EQ "Dual"){Write-Host "Dual Pvt IP & Public IP will be created" }
	elseif($ConfigIPs-EQ "Single"){Write-Host "Single Pvt IP & Public IP will be created" }
		elseif($ConfigIPs-EQ "PvtDualStat"){Write-Host "Dual Static Pvt IP & Public IP will be created" }
			elseif($ConfigIPs-EQ"PvtSingleStat"){Write-Host "Single Static Pvt IP & Public IP will be created" }
				elseif($ConfigIPs-EQ "SinglePvtNoPub"){Write-Host "Single Static Pvt IP & No Public IP" }
					elseif($ConfigIPs-EQ "StatPvtNoPubDual"){Write-Host "Dual Static Pvt IP & No Public IP"}
						elseif($ConfigIPs-EQ "StatPvtNoPubSingle"){Write-Host "Single Static Pvt IP & No Public IP"}
							elseif($ConfigIPs-EQ "NoPubDual"){Write-Host "Dual Pvt IP & No Public IP"}
	else {
	Write-Host "No Network Config Found - Warning" -ForegroundColor Red
	}
}

Function RegisterRP {
	Param(
		[string]$ResourceProviderNamespace
	)

	# Write-Host "Registering resource provider '$ResourceProviderNamespace'";
	Register-AzureRmResourceProvider -ProviderNamespace $ResourceProviderNamespace �Confirm:$false -WarningAction SilentlyContinue | Out-Null;
}

Function AvailSet {
	param(
		[string]$rg = $rg,
		[string]$Location = $Location,
		[string]$AvailSetName = $AvailSetName,
		[string]$AddAvailabilitySet = $AddAvailabilitySet
)
 try {
 If ($AddAvailabilitySet -eq 'True')
 {
 Write-Host "Availability Set configuration in process.." -ForegroundColor White
New-AzureRmAvailabilitySet -ResourceGroupName $rg -Name $AvailSetName -Location $Location -WarningAction SilentlyContinue | Out-Null
$AddAvailabilitySet = (Get-AzureRmAvailabilitySet -ResourceGroupName $rg -Name $AvailSetName).Id
$global:VirtualMachine = New-AzureRmVMConfig -VMName $VMName -VMSize $VMSize -AvailabilitySetID $AddAvailabilitySet -WarningAction SilentlyContinue
Write-Host "Availability Set has been configured" -ForegroundColor White
}
else
{
Write-Host "Skipping Availability Set configuration" -ForegroundColor White
$global:VirtualMachine = New-AzureRmVMConfig -VMName $VMName -VMSize $VMSize -WarningAction SilentlyContinue
}
	}

catch {
	Write-Host -foregroundcolor Red `
	"$($_.Exception.Message)"; `
	break
}
 }

 function Provvms {
	 param (
	[string]$rg = $rg,
	[string]$Location = $Location
	 )
	$ProvisionVMs = @($VirtualMachine);
try {
   foreach($provisionvm in $ProvisionVMs) {
		New-AzureRmVM -ResourceGroupName $rg -Location $Location -VM $VirtualMachine �Confirm:$false -WarningAction SilentlyContinue | Out-Null
		WriteResults # Provides Post-Deployment Description
						}
	}
catch {
	Write-Host -foregroundcolor Red `
	"$($_.Exception.Message)"; `
	break
}
	 }

Function AddDiskImage {
Write-Host "Completing image creation..." -ForegroundColor White
$global:osDiskCaching = "ReadWrite"
$global:OSDiskName = $VMName + "OSDisk"
$global:OSDiskUri = $StorageAccount.PrimaryEndpoints.Blob.ToString() + "vhds/" + $OSDiskName + ".vhd"
$global:VirtualMachine = Set-AzureRmVMOSDisk -VM $VirtualMachine -Name $OSDiskName -VhdUri $OSDiskUri -CreateOption "FromImage" -Caching $osDiskCaching -WarningAction SilentlyContinue
}

Function MakeImagePlanInfo_Bitnami_Lamp {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'lampstack',
	[string]$Skus = '5-6',
	[string]$version = 'latest',
	[string]$Product = 'lampstack',
	[string]$name = '5-6'
)
Write-Host "Image Creation in Process - Plan Info - LampStack" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_elastic {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'elastic-search',
	[string]$Skus = '2-2',
	[string]$version = 'latest',
	[string]$Product = 'elastic-search',
	[string]$name = '2-2'
)
Write-Host "Image Creation in Process - Plan Info - Elastic Search" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_jenkins {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'jenkins',
	[string]$Skus = '1-650',
	[string]$version = 'latest',
	[string]$Product = 'jenkins',
	[string]$name = '1-650'
)
Write-Host "Image Creation in Process - Plan Info - Jenkins" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Microsoft_ServerR {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'microsoft-r-products',
	[string]$offer = 'microsoft-r-server',
	[string]$Skus = 'msr80-win2012r2',
	[string]$version = 'latest',
	[string]$Product = 'microsoft-r-server',
	[string]$name = 'msr80-win2012r2'
)
Write-Host "Image Creation in Process - Plan Info - Microsoft R Server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_tomcat {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'tom-cat',
	[string]$Skus = '7-0',
	[string]$version = 'latest',
	[string]$Product = 'tom-cat',
	[string]$name = '7-0'
)
Write-Host "Image Creation in Process - Plan Info - Tom-Cat" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Bitnami_redis {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'redis',
	[string]$Skus = '3-2',
	[string]$version = 'latest',
	[string]$Product = 'redis',
	[string]$name = '3-2'
)
Write-Host "Image Creation in Process - Plan Info - Redis"
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_neos {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'neos',
	[string]$Skus = '2-0',
	[string]$version = 'latest',
	[string]$Product = 'neos',
	[string]$name = '2-0'
)
Write-Host "Image Creation in Process - Plan Info - neos"
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_hadoop {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'hadoop',
	[string]$Skus = '2-7',
	[string]$version = 'latest',
	[string]$Product = 'hadoop',
	[string]$name = '2-7'
)
Write-Host "Image Creation in Process - Plan Info - hadoop"
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_gitlab {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'gitlab',
	[string]$Skus = '8-5',
	[string]$version = 'latest',
	[string]$Product = 'gitlab',
	[string]$name = '8-5'
)
Write-Host "Image Creation in Process - Plan Info - gitlab"
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_jrubystack {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'jrubystack',
	[string]$Skus = '9-0',
	[string]$version = 'latest',
	[string]$Product = 'jrubystack',
	[string]$name = '9-0'
)
Write-Host "Image Creation in Process - Plan Info - jrubystack"
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Bitnami_mongodb {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'mongodb',
	[string]$Skus = '3-2',
	[string]$version = 'latest',
	[string]$Product = 'mongodb',
	[string]$name = '3-2'
)
Write-Host "Image Creation in Process - Plan Info - MongoDb" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_mysql {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'mysql',
	[string]$Skus = '5-6',
	[string]$version = 'latest',
	[string]$Product = 'mysql',
	[string]$name = '5-6'
)
Write-Host "Image Creation in Process - Plan Info - MySql" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_nginxstack {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'nginxstack',
	[string]$Skus = '1-9',
	[string]$version = 'latest',
	[string]$Product = 'nginxstack',
	[string]$name = '1-9'
)
Write-Host "Image Creation in Process - Plan Info - Nginxstack" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_nodejs {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'nodejs',
	[string]$Skus = '4-3',
	[string]$version = 'latest',
	[string]$Product = 'nodejs',
	[string]$name = '4-3'
)
Write-Host "Image Creation in Process - Plan Info - Nodejs" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Bitnami_postgresql {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'bitnami',
	[string]$offer = 'postgresql',
	[string]$Skus = '9-5',
	[string]$version = 'latest',
	[string]$Product = 'postgresql',
	[string]$name = '9-5'
)
Write-Host "Image Creation in Process - Plan Info - postgresql" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Oracle_linux {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Oracle',
	[string]$offer = 'Oracle-Linux',
	[string]$Skus = '7.2',
	[string]$version = 'latest',
	[string]$Product = 'Oracle-Linux',
	[string]$name = '7.2'
)
Write-Host "Image Creation in Process - Plan Info - Oracle Linux" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Oracle_weblogic {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Oracle',
	[string]$offer = 'Oracle-WebLogic-server',
	[string]$Skus = 'Oracle-WebLogic-Server',
	[string]$version = 'latest',
	[string]$Product = 'Oracle-WebLogic-Server',
	[string]$name = 'Oracle-WebLogic-Server'
)
Write-Host "Image Creation in Process - Plan Info - Oracle WebLogic" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Oracle_EntDB {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Oracle',
	[string]$offer = 'Oracle-database-Ee',
	[string]$Skus = '12.1.0.2',
	[string]$version = 'latest',
	[string]$Product = '12.1.0.2',
	[string]$name = 'Oracle-database-Ee'
)
Write-Host "Image Creation in Process - Plan Info - Oracle Enterprise Edition" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_Oracle_StdDB {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Oracle',
	[string]$offer = 'Oracle-database-Se',
	[string]$Skus = '12.1.0.2',
	[string]$version = 'latest',
	[string]$Product = '12.1.0.2',
	[string]$name = 'Oracle-database-Se'
)
Write-Host "Image Creation in Process - Plan Info - Oracle Standard Edition" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_SAP_ase {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'sap',
	[string]$offer = 'ase',
	[string]$Skus = 'ase_hourly',
	[string]$version = 'latest',
	[string]$Product = 'ase_hourly',
	[string]$name = 'ase'
)
Write-Host "Image Creation in Process - Plan Info - SAP - ASE" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_puppet_puppetent {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Puppet',
	[string]$offer = 'Puppet-Enterprise',
	[string]$Skus = '2016-1',
	[string]$version = 'latest',
	[string]$Product = '2016-1',
	[string]$name = 'Puppet-Enterprise'
)
Write-Host "Image Creation in Process - Plan Info - Puppet Enterprise" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_splunk {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Splunk',
	[string]$offer = 'splunk-enterprise-base-image',
	[string]$Skus = 'splunk-on-ubuntu-14-04-lts',
	[string]$version = 'latest',
	[string]$Product = 'splunk-on-ubuntu-14-04-lts',
	[string]$name = 'splunk-enterprise-base-image'
)
Write-Host "Image Creation in Process - Plan Info - Puppet Enterprise" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}
Function MakeImagePlanInfo_SolarWinds {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'solarwinds',
	[string]$offer = 'solarwinds-database-performance-analyzer',
	[string]$Skus = 'dpa-byol',
	[string]$version = 'latest',
	[string]$Product = 'solarwinds-database-performance-analyzer',
	[string]$name = 'dpa-byol'
)
Write-Host "Image Creation in Process - Plan Info - SolarWinds" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Barracuda_ng_firewall_hourly {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Barracudanetworks',
	[string]$offer = 'barracuda-ng-firewall',
	[string]$Skus = 'hourly',
	[string]$version = 'latest',
	[string]$Product = 'barracuda-ng-firewall',
	[string]$name = 'hourly'
)
Write-Host "Image Creation in Process - Plan Info - Barracuda Firewall " -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Barracuda_ng_firewall_byol {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Barracudanetworks',
	[string]$offer = 'barracuda-ng-firewall',
	[string]$Skus = 'byol',
	[string]$version = 'latest',
	[string]$Product = 'barracuda-ng-firewall',
	[string]$name = 'byol'
)
Write-Host "Image Creation in Process - Plan Info - Barracuda NG Firewall " -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Barracuda_spam_firewall_byol {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Barracudanetworks',
	[string]$offer = 'barracuda-spam-firewall',
	[string]$Skus = 'byol',
	[string]$version = 'latest',
	[string]$Product = 'barracuda-spam-firewall',
	[string]$name = 'byol'
)
Write-Host "Image Creation in Process - Plan Info - Barracuda SPAM Firewall " -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Barracuda_spam_firewall_hourly {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'Barracudanetworks',
	[string]$offer = 'barracuda-spam-firewall',
	[string]$Skus = 'hourly',
	[string]$version = 'latest',
	[string]$Product = 'barracuda-spam-firewall',
	[string]$name = 'hourly'
)
Write-Host "Image Creation in Process - Plan Info - Barracuda SPAM Firewall " -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_f5_bigip_good_byol {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'F5-networks',
	[string]$offer = 'f5-big-ip',
	[string]$Skus = 'f5-bigip-virtual-edition-good-byol',
	[string]$version = 'latest',
	[string]$Product = 'f5-big-ip',
	[string]$name = 'f5-bigip-virtual-edition-good-byol'
)
Write-Host "Image Creation in Process - Plan Info - F5 BIG IP - BYOL" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_f5_webappfire_byol {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'F5-networks',
	[string]$offer = 'f5-web-application-firewall',
	[string]$Skus = 'f5-waf-solution-byol',
	[string]$version = 'latest',
	[string]$Product = 'f5-web-application-firewall',
	[string]$name = 'f5-waf-solution-byol'
)
Write-Host "Image Creation in Process - Plan Info - F5 WebApp Firewall- BYOL" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Pfsense {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'netgate',
	[string]$offer = 'netgate-pfsense-appliance',
	[string]$Skus = 'pfsense-router-fw-vpn-225',
	[string]$version = 'latest',
	[string]$Product = 'netgate-pfsense-appliance',
	[string]$name = 'pfsense-router-fw-vpn-225'
)
Write-Host "Image Creation in Process - Plan Info - Pfsense" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine= Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Checkpoint {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'checkpoint',
	[string]$offer = 'check-point-r77-10',
	[string]$Skus = 'sg-ngtp',
	[string]$version = 'latest',
	[string]$Product = 'check-point-r77-10',
	[string]$name = 'sg-ngtp'
)
Write-Host "Image Creation in Process - Plan Info - Checkpoint" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_RedHat67 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "Redhat",
	[string]$offer = "rhel",
	[string]$Skus = "6.7",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - RedHat 6.7" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_RedHat72 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "Redhat",
	[string]$offer = "rhel",
	[string]$Skus = "7.2",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - Redhat 7.2" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_FreeBsd {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftOSTC",
	[string]$offer = "FreeBSD",
	[string]$Skus = "10.3",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - FreeBsd" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_CentOs {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "OpenLogic",
	[string]$offer = "Centos",
	[string]$Skus = "7.2",
	[string]$version = "latest"

)
Write-Host "Image Creation in Process - No Plan Info - CentOs" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_Suse {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "Suse",
	[string]$offer = "openSUSE",
	[string]$Skus = "13.2",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - SUSE" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_Ubuntu {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "Canonical",
	[string]$offer = "UbuntuServer",
	[string]$Skus = "14.04.4-LTS",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - Ubuntu" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImagePlanInfo_Chef {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = 'chef-software',
	[string]$offer = 'chef-server',
	[string]$Skus = 'azure_marketplace_100',
	[string]$version = 'latest',
	[string]$Product = 'chef-server',
	[string]$name = 'azure_marketplace_100'
)
Write-Host "Image Creation in Process - Plan Info - Chef" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMPlan -VM $VirtualMachine -Name $name -Publisher $Publisher -Product $Product
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -linux -ComputerName $VMName -Credential $Credential1
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_w2k12 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftWindowsServer",
	[string]$offer = "WindowsServer",
	[string]$Skus = "2012-R2-Datacenter",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - W2k12 server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_w2k8 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftWindowsServer",
	[string]$offer = "WindowsServer",
	[string]$Skus = "2008-R2-SP1",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - W2k8 server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_SharePoint2k13 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftSharePoint",
	[string]$offer = "MicrosoftSharePointServer",
	[string]$Skus = "2013",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - SharePoint 2013 server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_SharePoint2k16 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftSharePoint",
	[string]$offer = "MicrosoftSharePointServer",
	[string]$Skus = "2016",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - SharePoint 2016 server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_w2k16 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftWindowsServer",
	[string]$offer = "WindowsServer",
	[string]$Skus = "Windows-Server-Technical-Preview",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - W2k16 server" -ForegroundColor White
Write-Host 'Publisher:'$Publisher 'Offer:'$offer 'Sku:'$Skus 'Version:'$version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function MakeImageNoPlanInfo_sql2k16 {
param(
	[string]$VMName = $VMName,
	[string]$Publisher = "MicrosoftSQLServer",
	[string]$offer = "SQL2016-WS2012R2",
	[string]$Skus = "Enterprise",
	[string]$version = "latest"
)
Write-Host "Image Creation in Process - No Plan Info - SQL 2016" -ForegroundColor White
Write-Host $Publisher $offer $Skus $version
$global:VirtualMachine = Set-AzureRmVMOperatingSystem -VM $VirtualMachine -Windows -ComputerName $VMName -Credential $Credential1 -ProvisionVMAgent -EnableAutoUpdate -WinRMHttp -Verbose
$global:VirtualMachine = Set-AzureRmVMSourceImage -VM $VirtualMachine -PublisherName $Publisher -Offer $offer -Skus $Skus -Version $version
}

Function New-AzVnet {
param(
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$VNETName = $VNetName,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$vnetrg = $vnetrg,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$Location = $Location,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$AddRange = '10.120.0.0/21',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix1 = "10.120.0.0/25",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix1 = "gatewaysubnet",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix2 = "10.120.0.128/25",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix2 = 'perimeter',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix3 = "10.120.1.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix3 = "data",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix4 = "10.120.2.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix4 = "monitor",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix5 = "10.120.3.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix5 = "reporting",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix6 = "10.120.4.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix6 = "analytics",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix7 = "10.120.5.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix7 = "management",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetAddPrefix8 = "10.120.6.0/24",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$SubnetNameAddPrefix8 = "deployment"
)
ChkDependsvnet
validate-profile
WriteConfigVnet
$subnet1 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix1 -Name $SubnetNameAddPrefix1
$subnet2 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix2 -Name $SubnetNameAddPrefix2
$subnet3 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix3 -Name $SubnetNameAddPrefix3
$subnet4 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix4 -Name $SubnetNameAddPrefix4
$subnet5 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix5 -Name $SubnetNameAddPrefix5
$subnet6 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix6 -Name $SubnetNameAddPrefix6
$subnet7 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix7 -Name $SubnetNameAddPrefix7
$subnet8 = New-AzureRmVirtualNetworkSubnetConfig -AddressPrefix $SubnetAddPrefix8 -Name $SubnetNameAddPrefix8
Write-Host "Network Preparation in Process.."
New-AzureRmVirtualNetwork -Location $Location -Name $VNetName -ResourceGroupName $vnetrg -AddressPrefix $AddRange -Subnet $subnet1,$subnet2,$subnet3,$subnet4,$subnet5,$subnet6,$subnet7,$subnet8 �Confirm:$false -WarningAction SilentlyContinue -Force | Out-Null
Get-AzureRmVirtualNetwork -Name $VNetName -ResourceGroupName $vnetrg | Get-AzureRmVirtualNetworkSubnetConfig -WarningAction SilentlyContinue | Out-Null
Write-Host "Network Preparation completed" -ForegroundColor White
}

# End of Provision VNET Function
Function New-AzNSG {
param(

	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$NSGName = $NSGName,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$Location = $Location,
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$rg = $vnetrg,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$NSGEnabled = $NSGEnabled
)
validate-profile
ChkDependsnsg
Write-Host "Network Security Group Preparation in Process.."
$httprule = New-AzureRmNetworkSecurityRuleConfig -Name "FrontEnd_HTTP" -Description "HTTP Exception for Web frontends" -Protocol Tcp -SourcePortRange "80" -DestinationPortRange "80" -SourceAddressPrefix "*" -DestinationAddressPrefix "10.120.0.0/21" -Access Allow -Direction Inbound -Priority 200
$httpsrule = New-AzureRmNetworkSecurityRuleConfig -Name "FrontEnd_HTTPS" -Description "HTTPS Exception for Web frontends" -Protocol Tcp -SourcePortRange "443" -DestinationPortRange "443" -SourceAddressPrefix "*" -DestinationAddressPrefix "10.120.0.0/21" -Access Allow -Direction Inbound -Priority 201
$sshrule = New-AzureRmNetworkSecurityRuleConfig -Name "FrontEnd_SSH" -Description "SSH Exception for Web frontends" -Protocol Tcp -SourcePortRange "22" -DestinationPortRange "22" -SourceAddressPrefix "*" -DestinationAddressPrefix "10.120.0.0/21" -Access Allow -Direction Inbound ` -Priority 203
$nsg = New-AzureRmNetworkSecurityGroup -ResourceGroupName $rg -Location $Location -Name $NSGName -SecurityRules $httprule,$httpsrule, $sshrule �Confirm:$false -WarningAction SilentlyContinue -Force | Out-Null
Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $rg -WarningAction SilentlyContinue | Out-Null
Write-Host "Network Security Group configuration completed" -ForegroundColor White
$secrules =Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg -ExpandResource NetworkInterfaces | Get-AzureRmNetworkSecurityRuleConfig | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationPortRange,SourceAddressPrefix,Access
$defsecrules = Get-AzureRmNetworkSecurityGroup -Name $NSGName -ResourceGroupName $vnetrg -ExpandResource NetworkInterfaces | Get-AzureRmNetworkSecurityRuleConfig -DefaultRules | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationAddressPrefix,SourceAddressPrefix,Access
}
# End of Provision Network Security Groups Function

Function SubnetMatch {
	Param(
		[INT]$Subnet
	)
switch ($Subnet)
{
0 {Write-Host "Deploying to Subnet 10.120.0.0/25"}
1 {Write-Host "Deploying to Subnet 10.120.1.128/25"}
2 {Write-Host "Deploying to Subnet 10.120.1.0/24"}
3 {Write-Host "Deploying to Subnet 10.120.2.0/24"}
4 {Write-Host "Deploying to Subnet 10.120.3.0/24"}
5 {Write-Host "Deploying to Subnet 10.120.4.0/24"}
6 {Write-Host "Deploying to Subnet 10.120.5.0/24"}
7 {Write-Host "Deploying to Subnet 10.120.6.0/24"}
8 {Write-Host "Deploying to Subnet 10.120.7.0/24"}
9 {Write-Host "Deploying to Subnet 10.120.8.0/24"}
default {No Subnet Found}
}
}

Function Get-azNetinfo {
	param(
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$Location = $Location,
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$rg
	)

 try {
validate-profile
Get-AzureRmResourceGroup -Name $rg -Location $Location | Out-Null
}
catch {
	Write-Host -foregroundcolor Yellow `
	" $($_.Exception.Message)"; `
	continue
}
Write-Host "VNETs in RG" $rg -NoNewline
Get-AzureRmVirtualNetwork -ResourceGroupName $rg -WarningAction SilentlyContinue | ft Name, ResourceGroupName -Wrap -AutoSize

Write-Host "Subnets located in RG" $rg
Get-AzureRmVirtualNetwork -ResourceGroupName $rg | Get-AzureRmVirtualNetworkSubnetConfig | ft Name,AddressPrefix

Write-Host "Network Security Groups located in RG" $rg
Get-AzureRmNetworkSecurityGroup -ResourceGroupName $rg -WarningAction SilentlyContinue | ft "Name"

Write-Host "NICs located in RG" $rg
Get-AzureRmNetworkInterface -ResourceGroupName $rg | ft Name,Location,ResourceGroupName

Write-Host "VMs located in RG" $rg
Get-AzureRmVM -ResourceGroupName $rg | ft "Name"

Write-Host "Public Ips located in RG" $rg
Get-AzureRmPublicIpAddress -ResourceGroupName $rg | ft "Name","IpAddress"

Write-Host "Public DNS Records located in RG" $rg
Get-AzureRmPublicIpAddress -ResourceGroupName $rg | select-object -ExpandProperty DNSSettings | FT FQDN -Wrap

Write-Host "Private Network Interfaces located in " $rg
$vms = get-azurermvm -ResourceGroupName $rg
$nics = get-azurermnetworkinterface -ResourceGroupName $rg | where VirtualMachine -NE $null #skip Nics with no VM
foreach($nic in $nics)
{
	$vm = $vms | where-object -Property Id -EQ $nic.VirtualMachine.id
	$prv =  $nic.IpConfigurations | select-object -ExpandProperty PrivateIpAddress
	$alloc =  $nic.IpConfigurations | select-object -ExpandProperty PrivateIpAllocationMethod
	Write-Output "$($vm.Name): $prv - $alloc" | Format-Table
}

$nsgs = Get-AzureRmNetworkSecurityGroup -ResourceGroupName $rg | ft Name -HideTableHeaders -Wrap
#	$nsgs
# Get-AzureRmNetworkSecurityGroup -Name $nsgs -ResourceGroupName $rg -ExpandResource NetworkInterfaces | Get-AzureRmNetworkSecurityRuleConfig | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationPortRange,SourceAddressPrefix,Access
# Get-AzureRmNetworkSecurityGroup -Name $nsgs -ResourceGroupName $rg -ExpandResource NetworkInterfaces | Get-AzureRmNetworkSecurityRuleConfig -DefaultRules | Ft Name,Description,Direction,SourcePortRange,DestinationPortRange,DestinationAddressPrefix,SourceAddressPrefix,Access
}
Function WriteConfigVM {
$time = " Start Time " + (Get-Date -UFormat "%d-%m-%Y %H:%M:%S")
Write-Host VM CONFIGURATION - $time -ForegroundColor White
Write-Host "                                                               "
Write-Host "VM Name: $VMName " -ForegroundColor White
Write-Host "Resource Group Name: $rg"
Write-Host "Server Type: $Image"
Write-Host "Geo Location: $Location"
Write-Host "VNET Name: $vNetName"
Write-Host "Storage Account Name: $StorageName"
Write-Host "Storage Account Type: $StorageType"
SelectNicDescrtipt
If ($ConfigIPs -eq "StatPvtNoPubSingle")
{ Write-Host "Public Ip Will not be created" -ForegroundColor White
Write-Host "Nic1: $PvtIPNic1"
SubnetMatch $Subnet1
}
If ($ConfigIPs -eq "StatPvtNoPubDual")
{ Write-Host "Public Ip Will not be created" -ForegroundColor White
Write-Host "Nic1: $PvtIPNic1"
Write-Host "Nic2: $PvtIPNic2"
SubnetMatch $Subnet1
SubnetMatch $Subnet2
}
If ($ConfigIPs -eq "Single")
{ Write-Host "Public Ip Will be created"
SubnetMatch $Subnet1
}
If ($ConfigIPs -eq "Dual")
{ Write-Host "Public Ip Will be created"
SubnetMatch $Subnet1
SubnetMatch $Subnet2
}
If ($ConfigIPs -eq "PvtSingleStat")
{ Write-Host "Public Ip Will be created"
SubnetMatch $Subnet1
Write-Host "Nic1: $PvtIPNic1"
}
If ($ConfigIPs -eq "PvtDualStat")
{ Write-Host "Public Ip Will be created"
SubnetMatch $Subnet1
SubnetMatch $Subnet2
Write-Host "Nic1: $PvtIPNic1"
Write-Host "Nic2: $PvtIPNic2"
}
if($AddExtension -eq 'True') {
Write-Host "Extension selected for deployment: $AzExtConfig "
}
if($AddAvailabilitySet -eq 'True') {
Write-Host "Availability Set to 'True'"
Write-Host "Availability Set Name:  '$AvailSetName'"
}
else
{
Write-Host "Availability Set to 'False'" -ForegroundColor White
}
}

Function WriteConfigVnet {
$time = " Start Time " + (Get-Date -UFormat "%d-%m-%Y %H:%M:%S")
Write-Host VNET CONFIGURATION - $time -ForegroundColor White
Write-Host "                                                               "
Write-Host "Geo Location: $Location"
Write-Host "VNET Name: $vNetName"
Write-Host "VNET Resource Group Name: $vnetrg"
Write-Host "Address Range:  $AddRange"
if($NSGEnabled -eq 'True')
{
Write-Host "NSG Name: $NSGName"
}

}

Function WriteResults {
Write-Host "Completed Deployment of:"  -ForegroundColor White
Write-Host "VM Name: $VMName " -ForegroundColor White
Write-Host "Resource Group Name: $rg"
Write-Host "Server Type: $Image"
Write-Host "VNET Resource Group Name: $vnetrg" -ForegroundColor White
Write-Host "VNET Name: $VNetName" -ForegroundColor White
Write-Host "Storage Account Name:  $StorageName"

$vm = Get-AzureRmvm -ResourceGroupName $rg -Name $VMName
$storage = $vm.StorageProfile
$disk = $storage.OsDisk
$Name = $disk.Name
$uri = $disk.Vhd
$avset = $vm.AvailabilitySetReference
$extension = $vm.Extensions
$extcount = $extension.Count
$statuscode = $vm.StatusCode


$availsetid = $avset.Id
$name = $vm.Name
$nicids = $vm.NetworkInterfaceIDs
$nicprofile = $vm.NetworkProfile
$nicprofiles = $nicprofile.NetworkInterfaces
$niccount = $nicprofiles.Count
$osprofile = $vm.OSProfile
$localadmin = $osprofile.AdminUsername
$provstate = $vm.ProvisioningState
$datad = $vm.DataDiskNames
$datadiskcount = $datad.Count

Write-Host "Server Name:"$name
Write-Host "Local admin:" $localadmin
if($extcount -ge 1)
	{Write-Host "Installed Azure Extensions Count" $extcount}
if($extcount -ge 1)
	{Write-Host "Data Disk Count:" $datadiskcount}

Write-Host "Provisioning State:" $provstate
Write-Host "Status Code:" $statuscode
Write-Host "Network Adapter Count:" $niccount
if($AddAvailabilitySet -eq 'True') 
{ Write-Host "Availability Set:"$availsetid }

if($AddExtension -eq 'True') {
Write-Host "Extension deployed: $AzExtConfig "
}
if($AddAvailabilitySet -eq 'True') {
Write-Host "Availability Set Configured"
Write-Host "Availability Set Name:  '$AvailSetName'"
$time = " Completed Time " + (Get-Date -UFormat "%d-%m-%Y %H:%M:%S")
Write-Host VM CONFIGURATION - $time -ForegroundColor White
Write-Host "                                                               "
}
else
{
$time = " Completed Time " + (Get-Date -UFormat "%d-%m-%Y %H:%M:%S")
Write-Host VM CONFIGURATION - $time -ForegroundColor White
Write-Host "                                                               "
}
}

Function EndState {
Write-Host "                                                               "
Write-Host "Private Network Interfaces for $rg"
$vms = get-azurermvm -ResourceGroupName $rg
$nics = get-azurermnetworkinterface -ResourceGroupName $rg | where VirtualMachine -NE $null #skip Nics with no VM
foreach($nic in $nics)
{
	$vm = $vms | where-object -Property Id -EQ $nic.VirtualMachine.id
	$prv =  $nic.IpConfigurations | select-object -ExpandProperty PrivateIpAddress
	$alloc =  $nic.IpConfigurations | select-object -ExpandProperty PrivateIpAllocationMethod
	Write-Output "$($vm.Name) : $prv , $alloc" | Format-Table
}

$pubip = Get-AzureRmPublicIpAddress -Name $InterfaceName1 -ResourceGroupName $rg -ErrorAction SilentlyContinue
$dns = Get-AzureRmPublicIpAddress -ExpandResource IPConfiguration -Name $InterfaceName1 -ResourceGroupName $rg -ErrorAction SilentlyContinue | select-object -ExpandProperty DNSSettings | select-object -ExpandProperty FQDN
if($pubip)
{
Write-Host "Public Network Interfaces for $rg"
Get-AzureRmPublicIpAddress -ResourceGroupName $rg| ft "Name","IpAddress" -Wrap
Get-AzureRmPublicIpAddress -ResourceGroupName $rg | select-object -ExpandProperty DNSSettings | FT FQDN -Wrap
}

Write-Host "                                                               "
}

Function ResultsRollup {
Write-Host "                                                               "
Write-Host "Storage Accounts for $rg" -NoNewLine
Get-AzurermStorageAccount -ResourceGroupName $rg -WarningAction SilentlyContinue | ft StorageAccountName,Location,ResourceGroupname -Wrap

if($AddAvailabilitySet -eq 'True'){
Write-Host "Availability Sets for $rg"
Get-AzurermAvailabilitySet -ResourceGroupName $rg -WarningAction SilentlyContinue | ft Name,ResourceGroupName -Wrap
}
}

Function New-AzResGrp
{
	Param(
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]$rg = $rg 
	)
validate-profile
New-AzureRmResourceGroup -Name $rg -Location $Location �Confirm:$false -WarningAction SilentlyContinue -Force | Out-Null
}
Function StorageNameCheck
{
	param(
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]$StorageName  = $StorageName
	)
$checkname =  Get-AzureRmStorageAccountNameAvailability -Name $StorageName | Select-Object -ExpandProperty NameAvailable
if($checkname -ne 'True') {
Write-Host "Storage Account Name in use, please choose a different name for your storage account"
Start-Sleep 5
break
}
}
Function New-AzStorage {
		param(
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$StorageName = $StorageName,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$rg = $rg,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[ValidateSet("Standard_LRS","Standard_GRS")]
		[string]
		$StorageType = $StorageType,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$Location = $Location
	)
Validate-Profile
StorageNameCheck
Write-Host "Starting Storage Creation.."
$Global:StorageAccount = New-AzureRmStorageAccount -ResourceGroupName $rg -Name $StorageName.ToLower() -Type $StorageType -Location $Location -ErrorAction Stop -WarningAction SilentlyContinue
Write-Host "Completed Storage Creation" -ForegroundColor White
} # Creates Storage

Function New-AzVM {
	param(
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]$VMName,
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("w2k12","w2k8","red67","red72","suse","free","ubuntu","centos","w2k16","sql2016","chef","check","pfsense","lamp","jenkins","nodejs","elastics","postgressql","splunk","puppet","serverr","solarwinds","f5bigip","f5appfire","barrahourngfw","barrabyolngfw","barrahourspam","barrabyolspam","mysql","share2013","share2016","mongodb","nginxstack","hadoop","neos","tomcat","redis","gitlab","jruby")]
	[string]
	$Image = 'w2k12',
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("Single","Dual","NoPubDual","PvtDualStat","StatPvtNoPubSingle","PvtSingleStat","StatPvtNoPubDual","NoPubSingle")]
	[string]
	$ConfigIps = 'Single',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$GenerateName = -join ((65..90) + (97..122) | Get-Random -Count 6 | % {[char]$_}) + "aip",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$StorageName = $VMName + 'str',
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$rg = 'resgrp',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("True","False")]
	[string]
	$NSGEnabled = 'False',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$NSGName = 'nsg',
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$vnetrg = 'resgrp',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("Standard_LRS","Standard_GRS")]
	[string]
	$StorageType = 'Standard_GRS',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$Location = $Location,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("True","False")]
	[string]
	$AddAvailabilitySet = 'False',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$AvailSetName = $GenerateName,
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$VNETName = 'vnet',
	[Parameter(Mandatory=$True,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$AddVnet = 'True',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$InterfaceName1 = $VMName + "_nic1",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$InterfaceName2 = $VMName + "_nic2",
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateRange(0,8)]
	[int]
	$Subnet1 = 2,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateRange(0,8)]
	[int]
	$Subnet2 = 3,
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ipaddress]
	$PvtIPNic1 = '127.0.0.1',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]	
	[ipaddress]
	$PvtIPNic2 = '127.0.0.1',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$DNLabel = 'mydns1',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[ValidateSet("True","False")]
	[string]
	$AddFQDN = 'False',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$VMSize = 'Standard_A3',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$locadmin = 'localadmin',
	[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
	[string]
	$locpassword = 'P@ssW0rd!'

	)
$SecureLocPassword = Convertto-SecureString $locpassword �asplaintext -Force
$Credential1 = New-Object System.Management.Automation.PSCredential ($locadmin,$SecureLocPassword)

switch -Wildcard ($Image)
	{
		"*pfsense*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Pfsense # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*free*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_FreeBsd  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*red72*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_RedHat72  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*red67*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_RedHat67  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*w2k12*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_w2k12  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*sql2016*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_sql2k16  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*check*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Checkpoint  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*cent*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_CentOs  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*Suse*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_Suse  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*w2k8*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_w2k8  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*w2k16*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_w2k16  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*chef*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Chef  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*lamp*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_Lamp # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*mongodb*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_mongodb # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*mysql*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_mysql # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*elastics*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_elastic # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*nodejs*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_nodejs # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*nginxstack*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_nginxstack # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*postgressql*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_postgresql # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*oracle-linux*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Oracle_linux # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*web-logic*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Oracle_weblogic # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*entdb-oracle*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Oracle_EntDB  # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*stddb-oracle*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Oracle_StdDB # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*puppet*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_puppet_puppetent # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*splunk*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_splunk # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*share2013*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_SharePoint2k13 # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*share2016*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_SharePoint2k16 # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*serverr*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Microsoft_Serverr # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*ubuntu*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImageNoPlanInfo_Ubuntu # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*f5bigip*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_f5_bigip_good_byol # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*f5appfire*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_f5_webappfire_byol # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*barrahourngfw*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Barracuda_ng_firewall_hourly # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*barrabyolngfw*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Barracuda_ng_firewall_byol # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*barrahourspam*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Barracuda_spam_firewall_hourly # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*barrabyolspam*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Barracuda_spam_firewall_byol # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*sap*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_SAP_ase # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*solarwinds*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_SolarWinds # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*hadoop*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_hadoop # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*tomcat*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_tomcat # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*redis*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_redis # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*neos*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_neos # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*gitlab*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_gitlab # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*jruby*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_jrubystack # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		"*jenkins*" {
			ChkDepends
			WriteConfigVM
			New-AZStorage
			AvailSet
			ConfigNet  #Sets network connection info
			MakeImagePlanInfo_Bitnami_jenkins # Begins Image Creation
			ConfigSet # Adds Network Interfaces
			AddDiskImage # Completes Image Creation
			Provvms
			NSGEnabled
}
		default{"An unsupported image was referenced"}
	}
}

Function ExtCompatWin {
if($Image -eq 'w2k12') {Write-Host "Found Windows $Image"}
	elseif($Image -eq 'w2k8') {Write-Host "Found Windows $Image"}
		elseif($Image -eq 'w2k16') {Write-Host "Found Windows $Image"}
			elseif($Image -eq 'share2013'){Write-Host "Found Windows $Image"}
				elseif($Image -eq 'sql2016') {Write-Host "Found Windows $Image"}
					elseif($Image -eq 'share2016') {Write-Host "Found Windows $Image"}
else {
Write-Host "No Compatble OS Found, please verify the extension is compatible with $Image"
exit
}
}
Function ExtCompatLin {
if($Image -eq 'red67') {Write-Host "Found Linux" $Image}
	elseif($Image -eq 'suse') {Write-Host "Found Linux $Image"}
		elseif($Image -eq 'ubuntu') {Write-Host "Found Linux $Image"}
			elseif($Image -eq 'free'){Write-Host "Found Linux $Image"}
				elseif($Image -eq 'centos') {Write-Host "Found Linux $Image"}
					elseif($Image -eq 'red72') {Write-Host "Found Linux $Image"}
else {
Write-Host "No Compatble OS Found, please verify the extension is compatible with $Image"
exit
}
}
Function TestUpload {
$folderexist = Test-Path -Path $localFolder
if(!$folderexist)
{
Write-Host "Folder Doesn't Exist"
exit }
else
{ Upload }
}

Function Upload {
$Keys = Get-AzureRmStorageAccountKey -ResourceGroupName $rg -Name $StorageName;
$StorageContext = New-AzureStorageContext -StorageAccountName $StorageName -StorageAccountKey $Keys[0].Value;
New-AzureStorageContainer -Context $StorageContext -Name $containerName;
$storageAccountKey = Get-AzureRmStorageAccountKey -ResourceGroupName $rg -Name $StorageName;
$blobContext = New-AzureStorageContext -StorageAccountName $StorageName -StorageAccountKey $Keys[0].Value;
$files = Get-ChildItem $localFolder
foreach($file in $files)
{
  $fileName = "$localFolder\$file"
  $blobName = "$file"
  write-host "copying $fileName to $blobName"
  Set-AzureStorageBlobContent -File $filename -Container $containerName -Blob $blobName -Context $blobContext -Force -BlobType Append
  Get-AzureStorageBlob -Container $containerName -Context $blobContext -Blob $blobName
}
write-host "All files in $localFolder uploaded to $containerName!"
}

Function Install-Ext {
	param(
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[ValidateSet("True","False")]
		[string]
		$AddExtension = 'False',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[ValidateSet("diag","msav","access","linuxbackup","chefagent","eset","customscript","opsinsightLinux","opsinsightWin","WinPuppet","domjoin","RegisterAzDSC")]
		[string]
		$AzExtConfig = 'diag',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$Location = $Location,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$rg = $rg,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$StorageName = $StorageName,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$VMName = $VMName,
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$containerName = 'scripts',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$DomName = 'mydom.local',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$customextname = 'customscript',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$scriptname = 'WFirewall.ps1',
		[Parameter(Mandatory=$False,ValueFromPipelinebyPropertyName=$true)]
		[string]
		$Azautoacct = "DSC-Auto"
	)
switch ($AzExtConfig)
	{
		"access" {
ExtCompatWin
Write-Host "VM Access Agent VM Image Preparation in Process"
Set-AzureRmVMAccessExtension -ResourceGroupName $rg -VMName $VMName -Name "VMAccess" -typeHandlerVersion "2.0" -Location $Location -Verbose -username $locadmin -password $locpassword | ft ProvisioningState
Get-AzureRmVMAccessExtension -ResourceGroupName $rg -VMName $VMName -Name "VMAccess" -Status
Write-Host  "Added VM Access Extension"
}
		"msav" {
ExtCompatWin
Write-Host "MSAV Agent VM Image Preparation in Process"
Set-AzureRmVMExtension  -ResourceGroupName $rg -VMName $VMName -Name "MSAVExtension" -ExtensionType "IaaSAntimalware" -Publisher "Microsoft.Azure.Security" -typeHandlerVersion 1.4 -Location $Location | ft ProvisioningState
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "MSAVExtension" -Status
Write-Host  "Added VM msav Extension"
}
		"customscript" {
Write-Host "Updating server with custom script"
if($CustomScriptUpload -eq 'True')
{
TestUpload
}
Set-AzureRmVMCustomScriptExtension -Name $customextname -ContainerName $containerName -ResourceGroupName $rg -VMName $VMName -StorageAccountName $StorageName -FileName $scriptname -Location $Location -TypeHandlerVersion "1.1" | Out-Null
Get-AzureRmVMCustomScriptExtension -ResourceGroupName $rg -VMName $VMName -Name $customextname -Status | Out-Null
Write-Host  "Added VM Custom Script Extension"
}
		"diag" {
Write-Host "Adding Azure Enhanced Diagnostics"
Set-AzureRmVMAEMExtension -ResourceGroupName $rg -VMName $VMName -WADStorageAccountName $StorageName -InformationAction SilentlyContinue -WarningAction SilentlyContinue | Out-Null
Get-AzureRmVMAEMExtension -ResourceGroupName $rg -VMName $VMName | Out-Null
Write-Host  "Added VM Enhanced Diag Extension"
}
		"domjoin" {
ExtCompatWin
$DomName = 'aip.local'
Write-Host "Domain Join active"
Set-AzureRmVMADDomainExtension -DomainName $DomName -ResourceGroupName $rg -VMName $VMName -Location $Location -Name 'DomJoin' -WarningAction SilentlyContinue -Restart | Out-Null
Get-AzureRmVMADDomainExtension -ResourceGroupName $rg  -VMName $VMName -Name 'DomJoin' | Out-Null
Write-Host  "Added VM Domain Join Extension"
}
		"linuxOsPatch" {
ExtCompatLin
Write-Host "Adding Azure OS Patching Linux"
Set-AzureRmVMExtension -VMName $VMName -ResourceGroupName $rg -Location $Location -Name "OSPatch" -ExtensionType "OSPatchingForLinux" -Publisher "Microsoft.OSTCExtensions" -typeHandlerVersion "2.0" -InformationAction SilentlyContinue -Verbose
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "OSPatch"
Write-Host  "Added VM OS Patch Extension"
		}
		"linuxbackup" {
ExtCompatLin
Write-Host "Adding Linux VMBackup"
Set-AzureRmVMBackupExtension -VMName $VMName -ResourceGroupName $rg -Name "VMBackup" -Tag "OSBackup" -WarningAction SilentlyContinue
Write-Host  "Added VM Backup Extension"
		}
		"chefAgent" {
Write-Host "Adding Chef Agent"
$ProtectedSetting = ''
$Setting = ''
Set-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "ChefStrap" -ExtensionType "ChefClient" -Publisher "Chef.Bootstrap.WindowsAzure" -typeHandlerVersion "1210.12" -Location $Location -Verbose -ProtectedSettingString $ProtectedSetting -SettingString $Setting
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "ChefStrap"
Write-Host  "Added VM Chef Extension"
}
		"opsinsightLinux" {
ExtCompatLin
Write-Host "Adding Linux Insight Agent"
Set-AzureRmVMExtension -VMName $VMName -ResourceGroupName $rg -Location $Location -Name "OperationalInsights" -ExtensionType "OmsAgentForLinux" -Publisher "Microsoft.EnterpriseCloud.Monitoring" -typeHandlerVersion "1.0" -InformationAction SilentlyContinue -Verbose
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "OperationalInsights"
Write-Host  "Added OpsInsight Extension"
}
		"opsinsightWin" {
ExtCompatWin
Write-Host "Adding Windows Insight Agent"
Set-AzureRmVMExtension -VMName $VMName -ResourceGroupName $rg -Location $Location -Name "OperationalInsights" -ExtensionType "MicrosoftMonitoringAgent" -Publisher "Microsoft.EnterpriseCloud.Monitoring" -typeHandlerVersion "1.0" -InformationAction SilentlyContinue -Verbose
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "OperationalInsights"
Write-Host  "Added OpsInsight Extension"
}
		"ESET" {
ExtCompatWin
Write-Host "Setting File Security"
Set-AzureRmVMExtension -VMName $VMName -ResourceGroupName $rg -Location $Location -Name "ESET" -ExtensionType "FileSecurity" -Publisher "ESET" -typeHandlerVersion "6.0" -InformationAction SilentlyContinue -Verbose
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "ESET"
Write-Host  "Added ESET Extension"
}
		"RegisterAzDSC" {
Write-Host "Registering with Azure Automation DSC"
$ActionAfterReboot = 'ContinueConfiguration'
$configmode = 'ApplyAndAutocorrect'
$AutoAcctName = $Azautoacct
$NodeName = -join $VMNAME+".node"
$ConfigurationName = -join $VMNAME+".node"
Register-AzureRmAutomationDscNode -AutomationAccountName $AutoAcctName -AzureVMName $VMName -ActionAfterReboot $ActionAfterReboot -ConfigurationMode $configmode -RebootNodeIfNeeded $True -ResourceGroupName $rg -NodeConfigurationName $ConfigurationName -AzureVMLocation $Location -AzureVMResourceGroup $rg -Verbose
Write-Host  "Registered with Azure Automation DSC"
}
		"WinPuppet" {
ExtCompatWin
Write-Host "Deploying Puppet Extension"
Set-AzureRmVMExtension -VMName $VMName -ResourceGroupName $rg -Location $Location -Name "PuppetEnterpriseAgent" -ExtensionType "PuppetEnterpriseAgent" -Publisher "PuppetLabs" -typeHandlerVersion "3.2" -InformationAction SilentlyContinue -Verbose
Get-AzureRmVMExtension -ResourceGroupName $rg -VMName $VMName -Name "PuppetEnterpriseAgent"
Write-Host  "Added Puppet Agent Extension"
}
		default{"An unsupported Extension command was used"
break
}
	}
} # Deploys Azure Extensions

Function OrphanChk {
	param(
		[string]$InterfaceName1  = $InterfaceName1,
		[string]$InterfaceName2  = $InterfaceName2,
		[string]$Location = $Location,
		[string]$rg = $rg,
		[string]$VMName = $VMName
	)
$extvm = Get-AzureRmVm -Name $VMName -ResourceGroupName $rg -ErrorAction SilentlyContinue
$nic1 = Get-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -ErrorAction SilentlyContinue
$nic2 = Get-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -ErrorAction SilentlyContinue
$pubip =  Get-AzureRmPublicIpAddress -Name $InterfaceName1 -ResourceGroupName $rg -ErrorAction SilentlyContinue

if($extvm)
{ Write-Host "Host VM Found, please use a different VMName for Provisioning or manually delete the existing VM" -ForegroundColor Red
 Start-sleep 10
Exit }
else {if($nic1)
{ Write-Host "Nic1 already Exists, removing orphan" -ForegroundColor DarkYellow
Remove-AzureRmNetworkInterface -Name $InterfaceName1 -ResourceGroupName $rg -Force -Confirm:$False
 }
	 if($pubip)
{ Write-Host "PublicIp already Exists, removing orphan" -ForegroundColor DarkYellow
				  Remove-AzureRmPublicIpAddress -Name $InterfaceName1 -ResourceGroupName $rg -Force -Confirm:$False
}
	 if($nic2)
{ Write-Host "Nic2 already Exists, removing orphan" -ForegroundColor DarkYellow
				  Remove-AzureRmNetworkInterface -Name $InterfaceName2 -ResourceGroupName $rg -Force -Confirm:$False
 }
 else {Write-Host "No Orphans Found, proceeding with deployment.." -ForegroundColor Green}
 }
} # Verifies no left over components will prohibit deployment of the new VM, cleans up any if the exist.

Export-ModuleMember -Function New-AzResGrp
Export-ModuleMember -Function New-AzStorage
Export-ModuleMember -Function New-AzVM
Export-ModuleMember -Function New-AzVnet
Export-ModuleMember -Function New-AzNSG
Export-ModuleMember -Function Install-Ext
Export-ModuleMember -Function Get-azNetinfo